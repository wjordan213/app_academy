JournalApp.Models.Post = Backbone.Model.extend ({
  urlRoot: '/posts'

});
